<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="<?php echo e(asset('fontend/css/infor.css')); ?>" rel="stylesheet" type="text/css"/>
        <title>Thông tin cá nhân</title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script>
            function chooseFile(fileInput) {
                if (fileInput.files && fileInput.files[0]){
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        $('#image').attr('src', e.target.result);
                    }
                    reader.readAsDataURL(fileInput.files[0]);
                }
            }
        </script>
    </head>
    <body>
        <div class="infor-form">
            <form>
                <h1>Thông tin cá nhân</h1>
                <div class="box">
                    <div class="input-box">
                        <span class="thuoctinh">Tên Công Ty  </span>
                        <input type="text" name="txtTenconty" placeholder="Nhập họ và tên" required>
                    </div>
                    <div class="input-box">
                        <span class="thuoctinh">Logo Công Ty </span>
                        <input type="file" name="hinhanh" required>
                    </div>
                    <div class="input-box">
                        <span class="thuoctinh">Email </span>
                        <input type="email" name="txtEmail" placeholder="Nhập địa chỉ email" required>
                    </div>
                    <div class="input-box">
                        <span class="thuoctinh">Link website hoặc facebook </span>
                        <input type="text" name="txtLink" placeholder="Nhập địa Chỉ" required>
                    </div>
                    <div class="input-box">
                        <label for="ngaysinh">GiớI Thiệu về công ty</label>
                        <br>
                        <textarea rows="3" name="txtGioithieu" placeholder="Giới thiệu về công ty" required></textarea>
                    </div>

                <div class="input-box">
                    <label for="gioithieu">Địa Chỉ</label>
                    <br>
                    <textarea rows="3" name="txtDiachi" placeholder="Địa chỉ công ty" required></textarea>
                </div>
                <div class="input-box">
                    <span class="thuoctinh">Số điện thoại </span>
                    <input type="email" name="txtSDT" placeholder="Nhập địa số điện thoại" required>
                </div>                       
                    <a href="#">
                    <span></span>
                    <span></span>
                    Save
                </a>
            </form>
        </div>
    </body>
</html><?php /**PATH C:\laragon\www\website_hotrotimkiemvieclamit\resources\views/add_info_sv.blade.php ENDPATH**/ ?>