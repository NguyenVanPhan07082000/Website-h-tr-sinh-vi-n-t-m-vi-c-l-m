
<?php $__env->startSection('title'); ?>
    Sửa Cẩm Nang
<?php $__env->stopSection(); ?>
<?php $__env->startSection('add-Admin'); ?>
<div class="position-center">
    <?php
        $messenger = Session()->get('messenger');
        if($messenger)
        {
            echo '<script> alert("'.$messenger.'"); </script>';
            session()->put('messenger', null);
        }
    ?>
    <?php $__currentLoopData = $edit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edit_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form role="form" action="<?php echo e(URL::to('/admin/update-camnang/'.$edit_value->idCamnan)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            
                <div class="form-group">
                    <label for="exampleInputEmail1">Tên Cẩm Nang</label>
                    <input type="text" class="form-control" value="<?php echo e($edit_value->Tencamnan); ?>" name="txtTen" id="txtTen" placeholder="Nhập tên cẩm nang..." required>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Tiêu Đề</label>
                    <input type="text" class="form-control" value="<?php echo e($edit_value->Tieude); ?>" name="txtTieude" id="txtTieude" placeholder="Nhập tiêu đề cẩm nang..." required>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Giới Thiệu</label>
                    <textarea rows="4" class="form-control" name="txtGioithieu" id="txtGioithieu" placeholder="Giới thiệu về cẩm nang..." required><?php echo e($edit_value->Gioithieu); ?></textarea>
                </div>
            
            <button type="submit" class="btn btn-info">Lưu</button>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\website_hotrotimkiemvieclamit\resources\views/page/edit_camnang.blade.php ENDPATH**/ ?>