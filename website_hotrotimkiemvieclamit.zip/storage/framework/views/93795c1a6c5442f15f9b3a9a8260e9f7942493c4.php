
<?php $__env->startSection('title'); ?>
    Việc Làm Hết Hạn
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
<ul class="sidebar-menu" id="nav-accordion">
    <li class="sub-menu">
        <a class="active" href="javascript:;">
            <i class="fa fa-book"></i>
            <span>Quản Lý Việc Làm</span>
        </a>
        <ul class="sub">
            <li><a href="<?php echo e(URL::to('/admin/tat-ca-viec-lam')); ?>">Tất Cả Việc Làm</a></li>
            <li><a href="<?php echo e(URL::to('/admin/viec-lam-cho-duyet')); ?>">Việc Làm Chờ Duyệt</a></li>
            <li><a class="active" href="<?php echo e(URL::to('/admin/viec-lam-het-han')); ?>">Việc Làm Hết Hạn</a></li>
        </ul>
    </li>
    <li class="sub-menu">
        <a href="javascript:;">
            <i class="fa fa-th"></i>
            <span>Quản Lý Cẩm Nang</span>
        </a>
        <ul class="sub">
            <li><a href="<?php echo e(URL::to('/admin/tat-ca-cam-nang')); ?>">Tất Cả Cẩm Nang</a></li>
            <li><a href="<?php echo e(URL::to('/admin/them-cam-nang')); ?>">Thêm Cẩm Nang</a></li>
        </ul>
    </li>
    <li class="sub-menu">
        <a href="javascript:;">
            <i class="fa fa-tasks"></i>
            <span>Quảng Lý Quảng Cáo</span>
        </a>
        <ul class="sub">
            <li><a href="<?php echo e(URL::to('/admin/tat-ca-quang-cao')); ?>">Tất Cả Quảng Cáo</a></li>
            <li><a href="<?php echo e(URL::to('/admin/them-quang-cao')); ?>">Thêm Quảng Cáo</a></li>
        </ul>
    </li>
    <li class="sub-menu">
        <a href="javascript:;">
            <i class="fa fa-tasks"></i>
            <span>Quản Lý Admin </span>
        </a>
        <ul class="sub">
            <li><a href="<?php echo e(URL::to('/admin/tat-ca-admin')); ?>">Tất Cả Thông Tin Admin</a></li>
            <li><a href="<?php echo e(URL::to('/admin/them-admin')); ?>">Thêm Admin</a></li>
        </ul>
    </li>
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('job_end'); ?>
<div class="form">
    <form class="cmxform form-horizontal " id="signupForm" method="get" action="" novalidate="novalidate">
        <div class="quanly_table">
            <table class="table_quanly">
                <tr class="table_rows">
                    <th class="th td_stt">ID</th>
                    <th class="th td_tct">Tên Công Ty</th>
                    <th class="th td_tvl">Tên Việc Làm</th>
                    <th class="th td_tgd">Hạn Nộp</th>
                    <th class="th td_sk">Sự Kiện</th>
                </tr>
                <?php $__currentLoopData = $all_Job; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $all_job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="table_rows table_row-content">
                        <td class="td td_stt"><?php echo e($all_job->idJob); ?></td>
                        <td class="td td_tct"><?php echo e($all_job->Tencongty); ?></td>
                        <td class="td td_tvl"><a href="#" class="card_a-job"><?php echo e($all_job->Nganhnghe); ?></a></td>
                        <td class="td td_tgd"><?php echo e($all_job->Ngayhethan); ?></td>
                        <td class="td td_sk">
                            <a onclick="return confirm('Bạn có chắc muốn xoá?')" href="<?php echo e(URL::to('/admin/delete-job/'.$all_job->idJob)); ?>" class="btn-new">Xoá</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\website_hotrotimkiemvieclamit\resources\views/page/job_end.blade.php ENDPATH**/ ?>