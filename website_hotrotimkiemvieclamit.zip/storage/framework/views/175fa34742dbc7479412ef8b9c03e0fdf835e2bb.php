
<?php $__env->startSection('title'); ?>
    Sửa Quảng Cáo
<?php $__env->stopSection(); ?>
<?php $__env->startSection('add-Admin'); ?>
<div class="position-center">
    <?php
        $messenger = Session()->get('messenger');
        if($messenger)
        {
            echo '<script> alert("'.$messenger.'"); </script>';
            session()->put('messenger', null);
        }
    ?>
    <?php $__currentLoopData = $edit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edit_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form role="form" action="<?php echo e(URL::to('/admin/update-quangcao/'.$edit_value->idQuangcao)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            
            <div class="form-group">
                <label for="exampleInputPassword1">Slogan Quảng Cáo</label>
                <textarea rows="4" class="form-control" name="txtSlogan" id="txtSlogan" placeholder="Giới thiệu về cẩm nang..." required><?php echo e($edit_value->Slogan); ?></textarea>
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Link</label>
                <input type="text" class="form-control" name="txtLink" value="<?php echo e($edit_value->Link); ?>" id="txtLink" placeholder="Nhập tiêu đề cẩm nang..." required>
            </div>
            <button type="submit" class="btn btn-info">Submit</button>
        </form>
            
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\website_hotrotimkiemvieclamit\resources\views/page/edit_quangcao.blade.php ENDPATH**/ ?>