<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <script type="text/javascript" src="http://code.jquery.com/jquery-3.4.1.min.js"></script>		
        <script src="https://kit.fontawesome.com/a076d05399.js"></script>
        <link rel="stylesheet" href="<?php echo e(asset('fontend/css/changepw.css')); ?>">
        <title>Change Password</title>
    </head>
    <body>
        <div class="changepw">
            <form action="<?php echo e(URL::to('/save-matkhau')); ?>" method="POST" enctype="multipart/form-data">
                <h1>Change Password</h1>
                <div class="form-change">
                    <i class="fas fa-user"></i>
                    <input type="text" name="txtUser" placeholder="User name" required>
                </div>
                <div class="form-change">
                    <i class="fas fa-unlock"></i>
                    <input type="password" name="txtPass" placeholder="Password"required>
                </div>
                <div class="form-change">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="txtNhaplai" placeholder="New password"required>
                </div>
                <a href="" class="btn btn-white btn-animated">Thoát</a>
                <input type="submit" name="btnsubmit" class="btn btn-white btn-animated" value="Save"/>
            </form>       
        </div>   
    </body>
    </html><?php /**PATH C:\laragon\www\website_hotrotimkiemvieclamit\resources\views/doimatkhau.blade.php ENDPATH**/ ?>