
<?php $__env->startSection('header'); ?>
<header class="header">
    <div class="header__logo-box">
        <img src="<?php echo e(asset('fontend/img/logo.png')); ?>" class="header__logo-box__logo" alt="logo"/>
    </div>
    <div class="header__text-box">
        <h3 class="heading-primary">
            <span class="heading-primary_main">WELCOME TO</span>
            <span class="heading-primary_sub">Blue Star Website</span>
        </h3>
    </div>
    <div class="header__text-box2">
        <input type="text" name="find_name" id="find_name" placeholder="Nhập chức vụ ứng tuyển..." class="header__text-box2__find_name header__text-box2__find_text"/>
        <input type="text" name="find_type" id="find_type" placeholder="Nhập địa điểm..." class="header__text-box2__find_type header__text-box2__find_text"/>
        <a href="#" class="btn btn-white btn-animated">Search Now</a>
    </div>
    <div class="header__profile">
        <a href="#" class="btn-name btn-profile"><img src="<?php echo e(asset('fontend/img/phan.jpg')); ?>" class="header__profile__avatar" align="middle" alt="avatar" />Phần Nguyễn</a>
        
    </div>
    <!-- <div class="header__login">
        <a href="#" class="btn-login btn-white">Đăng Ký</a>
        <a href="./project/login/login.html" class="btn-login btn-white">Đăng nhập</a>
    </div> -->
</header>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\website_hotrotimkiemvieclamit\resources\views/page/headerhome.blade.php ENDPATH**/ ?>