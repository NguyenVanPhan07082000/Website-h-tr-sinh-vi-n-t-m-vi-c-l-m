
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fontend/css/job.css')); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<img src="<?php echo e(asset('fontend/img/chamngon.jpg')); ?>" class="img_chamngon" alt="chamngon"/>
<div class="page_job row">
    <div class="col-2-of-3">
        <div class="row title">
            <div class="col-1-of-2">
                <h2 class="title_name">Danh sách ứng viên</h2>
            </div>
            <div class="col-1-of-2">
                <h2 class="title_number">x ứng viên</h2>
            </div>
        </div>
        <div class="main">
            <div class="job_all">
                <?php $__currentLoopData = $timuv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $uv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="job job--new ">
                        <div class="col-1-of-4">
                            <img src="<?php echo e(asset('fontend/img/avatar'.'/'.$uv->Hinhanh)); ?>" class="logo-company" alt="logo-company"/>
                        </div>
                        <div class="col-2-of-4 job_info job_info--new">
                            <p class="job_info job_info--name_job--new">
                                <a href="<?php echo e(URL::to('/profile'.'/'.$uv->idUser)); ?>" class="job_info--a"> <?php echo e($uv->Hoten); ?></a>
                            </p>
                            <p class="job_info job_info--address_new">
                                Ngày Sinh: <?php echo e($uv->Ngaysinh); ?>

                            </p>
                            <p class="job_info job_info--salary_new">
                                Số Điện Thoại: <?php echo e($uv->SDT); ?>

                            </p>
                            <p class="job_info job_info--name_company--new">
                                <?php echo e($uv->Chuyennganh); ?>

                            </p>
                            <p class="job_info job_info--rights_new">
                                Giới Thiệu: <?php echo e($uv->Gioithieu); ?>

                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\website_hotrotimkiemvieclamit\resources\views/page/ds_ungvien.blade.php ENDPATH**/ ?>