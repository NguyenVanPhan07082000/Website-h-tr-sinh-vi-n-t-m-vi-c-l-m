<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <script type="text/javascript" src="http://code.jquery.com/jquery-3.4.1.min.js"></script>		
        <script src="https://kit.fontawesome.com/a076d05399.js"></script>
        <link rel="stylesheet" href="<?php echo e(asset('fontend/css/register.css')); ?>">
        <title>Register</title>
    </head>
    <body>
        <h2>Bạn là?</h2>
            <div class="container">
                <a href="<?php echo e(URL::to('/ung-vien')); ?>" class="btn">Ứng Viên</a>
                <a href="<?php echo e(URL::to('/tuyen-dung')); ?>" class="btn">Nhà Tuyển Dụng</a>
            </div>
        </div>
    </body>
</html><?php /**PATH C:\laragon\www\website_hotrotimkiemvieclamit\resources\views/question.blade.php ENDPATH**/ ?>