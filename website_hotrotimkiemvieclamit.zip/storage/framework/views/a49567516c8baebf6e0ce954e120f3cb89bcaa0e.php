
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fontend/css/job.css')); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<img src="<?php echo e(asset('fontend/img/chamngon.jpg')); ?>" class="img_chamngon" alt="chamngon"/>
<div class="page_job row">
    <div class="col-2-of-3">
        <div class="row title">
            <div class="col-1-of-2">
                <h2 class="title_name">Tất cả việc làm</h2>
            </div>
            <div class="col-1-of-2">
                <h2 class="title_number">258,263 việc làm</h2>
            </div>
        </div>
        <div class="main">
            <div class="job_all">
                <?php $__currentLoopData = $newjob; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $nj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="job job--new ">
                        <div class="col-1-of-4">
                            <img src="<?php echo e(asset('fontend/img/company'.'/'.$nj->Hinhanh)); ?>" class="logo-company" alt="logo-company"/>
                        </div>
                        <div class="col-2-of-4 job_info job_info--new">
                            <p class="job_info job_info--name_job--new">
                                <a href="<?php echo e(URL::to('/info-job'.'/'.$nj->idJob)); ?>" class="job_info--a"> <?php echo e($nj->Nganhnghe); ?> </a>
                            </p>
                            <p class="job_info job_info--name_company--new">
                                <?php echo e($nj->Tencongty); ?>

                            </p>
                            <p class="job_info job_info--salary_new">
                                $ Lương: <?php echo e($nj->Luong); ?>

                            </p>
                            <p class="job_info job_info--address_new">
                                Địa chỉ: <?php echo e($nj->Diachi); ?>

                            </p>
                            <p class="job_info job_info--rights_new">
                                Quyền Lợi: <?php echo e($nj->Quyenloi); ?>

                            </p>
                        </div>
                        <div class="col-1-of-4 job_footer">
                            <a href="<?php echo e(URL::to('/like-job'.'/'.$nj->idJob)); ?>" class="btnSaveJob--1" name="btnSaveJob" id="btnSaveJob"><i class="fa fa-heart"> Lưu Việc làm</i></a>
                            <i class="fa fa-calendar datetime--1"> <?php echo e($nj->Ngaycapnhat); ?></i>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
            </div>
            
        </div>
    </div>
    <div class="col-1-of-3">
        <div class="row">
                <h2 class="info_job--details_title--1 h2">Việc làm nổi bậc</h2>
                <?php $__currentLoopData = $jobnoibac; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $jb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="job job--1">
                        <div class="col-1-of-4">
                            <img src="<?php echo e(asset('fontend/img/company'.'/'.$jb->Hinhanh)); ?>" class="logo-company_new--1" alt="logo-company"/>
                        </div>
                        <div class="col-3-of-4 job_info--1 job_info--1_new">
                            <p class="job_info--name_job--new_2">
                                <a href="<?php echo e(URL::to('/info-job'.'/'.$jb->idJob)); ?>" class="job_info--a"> <?php echo e($jb->Nganhnghe); ?> </a>
                            </p>
                            <p class="job_info--name_company--new_2">
                                <?php echo e($jb->Tencongty); ?>

                            </p>
                            <p class="job_info--salary_new--1">
                                $ Lương: <?php echo e($jb->Luong); ?>

                            </p>
                            <p class="job_info--address_new--1">
                                Địa chỉ: <?php echo e($jb->Diachi); ?>

                            </p>
                            <p class="job_info--rights_new--1">
                                Quyền Lợi: <?php echo e($jb->Quyenloi); ?>

                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\website_hotrotimkiemvieclamit\resources\views/page/all_job.blade.php ENDPATH**/ ?>