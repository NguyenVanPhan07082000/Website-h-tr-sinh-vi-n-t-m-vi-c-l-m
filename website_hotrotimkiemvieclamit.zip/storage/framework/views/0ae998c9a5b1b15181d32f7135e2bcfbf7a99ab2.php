
<?php $__env->startSection('add-Job'); ?>
<section id="main-content">
    <section class="wrapper">
        <div class="form-w3layouts">
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Thêm Admin
                        </header>
                        <div class="panel-body">
                            <div class="position-center">
                                <form role="form" action="<?php echo e(URL::to('/admin/save-admin')); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <?php
                                        $messenger = Session()->get('messenger');
                                        if($messenger)
                                        {
                                            echo '<script> alert("'.$messenger.'"); </script>';
                                            session()->put('messenger', null);
                                        }
                                    ?>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Tài Khoản</label>
                                        <input type="text" class="form-control" name="txtTk" id="txtTk" placeholder="Nhập tên tài khoản..." required>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Mật Khẩu</label>
                                        <input type="password" class="form-control" name="txtPass" id="txtPass" placeholder="Nhập mật khẩu..." required>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Họ Và Tên</label>
                                        <input type="text" class="form-control" name="txtTen" id="txtTen" placeholder="Nhập tên người dùng..." required>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Ngày Sinh</label>
                                        <input type="date" class="form-control" name="txtNgaysinh" id="txtNgaysinh" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Giới Tính</label>
                                        <select name="gioitinh">
                                            <option value="Nam">Nam</option>
                                            <option value="Nữ">Nữ</option>
                                            <option value="Khác">Khác</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Email</label>
                                        <input type="email" class="form-control" name="txtEmail" id="txtEmail" placeholder="Nhập email..." required>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Số Điện Thoại</label>
                                        <input type="tel" class="form-control" pattern="[0-9]{10}" name="txtSDT" id="txtSDT" placeholder="Nhập số điện thoại..." required>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Địa Chỉ</label>
                                        <textarea rows="4" class="form-control" name="txtDiachi" id="txtDiachi" placeholder="Giới địa chỉ..." required></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputFile">Hình Ảnh</label>
                                        <input type="file" name="hinhanh" id="exampleInputFile" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Quyền Quản Trị</label>
                                        <select name="quyenquantri">
                                            <option value="1">Quản Trị Viên</option>
                                            <option value="0">Cộng Tác Viên</option>
                                        </select>
                                    </div>
                                    <a href="" class="btn btn-info">Cancel</a>
                                    <button type="submit" name="submit" class="btn btn-info">Submit</button>
                            </form>
                            </div>

                        </div>
                    </section>

                </div>
            </div>
        </div>
    </section>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\website_hotrotimkiemvieclamit\resources\views/page/add-Job.blade.php ENDPATH**/ ?>